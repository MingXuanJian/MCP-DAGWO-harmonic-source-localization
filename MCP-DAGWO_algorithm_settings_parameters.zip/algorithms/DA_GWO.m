function [Best_score,Best_pos,curve,info] = DA_GWO(N,MaxIt,lb,ub,dim,fobj,opt)
%DA_GWO Dynamic-adaptive GWO without MCP proximal shrinkage or LSR.
% Used only for ablation: MCP objective + dynamic adaptive leadership.
    N = max(5,round(N)); lb = lb(:)'; ub = ub(:)';
    X = lb + rand(N,dim).*(ub-lb);
    fit = inf(N,1);
    for i = 1:N
        fit(i) = fobj(X(i,:));
    end
    [fit,ord] = sort(fit,'ascend'); X = X(ord,:);
    Alpha = X(1,:); AlphaScore = fit(1);
    Beta = X(2,:); Delta = X(3,:);
    HistBest = Alpha; HistBestScore = AlphaScore;
    curve = nan(MaxIt,1);

    for it = 1:MaxIt
        prog = it/MaxIt;
        a = 2*(1-prog^2);
        fmin = min(fit); favg = mean(fit);
        Xnew = X; fitNew = fit;
        for i = 1:N
            Xi = X(i,:);
            X1 = gwo_leader_update(Xi,Alpha,a);
            X2 = gwo_leader_update(Xi,Beta,a);
            X3 = gwo_leader_update(Xi,Delta,a);
            Xgwo = (X1+X2+X3)/3;
            if fit(i) <= favg
                omega = opt.omegaMin + (opt.omegaMax-opt.omegaMin)*(fit(i)-fmin)/(favg-fmin+eps);
            else
                omega = opt.omegaMax;
            end
            omega = max(opt.omegaMin,min(opt.omegaMax,omega));
            Xcand = Xi + omega.*(Xgwo-Xi);
            Xcand = BoundClampRow(Xcand,lb,ub);
            fcand = fobj(Xcand);
            if fcand < fit(i)
                Xnew(i,:) = Xcand; fitNew(i) = fcand;
            end
        end
        X = Xnew; fit = fitNew;
        [fit,ord] = sort(fit,'ascend'); X = X(ord,:);
        Alpha = X(1,:); AlphaScore = fit(1);
        Beta = X(2,:); Delta = X(3,:);
        if AlphaScore < HistBestScore
            HistBestScore = AlphaScore; HistBest = Alpha;
        end
        curve(it) = HistBestScore;
    end
    Best_score = HistBestScore; Best_pos = HistBest;
    info.AlphaScore = AlphaScore;
end
