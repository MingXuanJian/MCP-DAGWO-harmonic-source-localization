function [Best_score,Best_pos,curve,info] = MCP_DAGWO(N,MaxIt,lb,ub,dim,fobj,repairFcn,initSeeds,opt)
    N = max(5,round(N)); lb = lb(:)'; ub = ub(:)';
    X = initialize_population_dagwo(N,dim,lb,ub,initSeeds);
    fit = inf(N,1);
    for i = 1:N
        X(i,:) = repairFcn(X(i,:),1,MaxIt);
        fit(i) = fobj(X(i,:));
    end
    [fit,ord] = sort(fit,'ascend'); X = X(ord,:);
    Alpha = X(1,:); AlphaScore = fit(1);
    Beta = X(2,:);  BetaScore = fit(2);
    Delta = X(3,:); DeltaScore = fit(3);
    HistBest = Alpha; HistBestScore = AlphaScore;
    curve = nan(MaxIt,1);
    stall = 0; stallLimit = max(20,round(0.10*MaxIt));

    for it = 1:MaxIt
        prog = it/MaxIt;
        a = 2*(1-prog^2);
        fmin = min(fit); favg = mean(fit);
        Xnew = X; fitNew = fit;

        for i = 1:N
            Xi = X(i,:);
            X1 = gwo_leader_update(Xi,Alpha,a);
            X2 = gwo_leader_update(Xi,Beta,a);
            X3 = gwo_leader_update(Xi,Delta,a);
            Xgwo = (X1+X2+X3)/3;

            % dynamic adaptive weight, adapted from MCP-IWHO's fitness-based weight
            if fit(i) <= favg
                omega = opt.omegaMin + (opt.omegaMax-opt.omegaMin)*(fit(i)-fmin)/(favg-fmin+eps);
            else
                omega = opt.omegaMax;
            end
            omega = max(opt.omegaMin,min(opt.omegaMax,omega));
            Xcand = Xi + omega.*(Xgwo-Xi);

            if fit(i) > favg && rand < 0.35
                id = randperm(N,2);
                diffStep = X(id(1),:) - X(id(2),:);
                Xcand = Xcand + (0.10*(1-prog)+0.01).*rand(1,dim).*diffStep;
            end
            if rand < (0.15*(1-prog)+0.03)
                cauchyStep = tan(pi*(rand(1,dim)-0.5));
                Xcand = Xcand + (0.02*(1-prog)+0.003).*cauchyStep.*(ub-lb);
            end
            Xcand = BoundClampRow(Xcand,lb,ub);
            Xcand = repairFcn(Xcand,it,MaxIt);
            fcand = fobj(Xcand);
            if fcand < fit(i)
                Xnew(i,:) = Xcand; fitNew(i) = fcand;
            end
        end

        X = Xnew; fit = fitNew;
        X = [X; Alpha; Beta; Delta; HistBest];
        fit = [fit; AlphaScore; BetaScore; DeltaScore; HistBestScore];
        [fit,ord] = sort(fit,'ascend'); X = X(ord,:);
        X = X(1:N,:); fit = fit(1:N);

        Alpha = X(1,:); AlphaScore = fit(1);
        Beta  = X(2,:); BetaScore  = fit(2);
        Delta = X(3,:); DeltaScore = fit(3);

        if AlphaScore < HistBestScore - 1e-12
            HistBestScore = AlphaScore; HistBest = Alpha; stall = 0;
        else
            stall = stall + 1;
        end

        % restart only worst individuals, no LASSO/OMP/ENet injection
        if stall >= stallLimit
            nRestart = max(1,round(0.20*N));
            worstIdx = (N-nRestart+1):N;
            for k = 1:numel(worstIdx)
                idx = worstIdx(k);
                if rand < 0.5
                    xNew = lb + rand(1,dim).*(ub-lb);
                else
                    xNew = HistBest + 0.10*tan(pi*(rand(1,dim)-0.5)).*(ub-lb);
                end
                xNew = BoundClampRow(xNew,lb,ub);
                xNew = repairFcn(xNew,it,MaxIt);
                X(idx,:) = xNew; fit(idx) = fobj(xNew);
            end
            [fit,ord] = sort(fit,'ascend'); X = X(ord,:);
            Alpha = X(1,:); AlphaScore = fit(1);
            Beta  = X(2,:); BetaScore  = fit(2);
            Delta = X(3,:); DeltaScore = fit(3);
            stall = 0;
        end
        curve(it) = HistBestScore;
    end
    Best_score = HistBestScore; Best_pos = HistBest;
    info.AlphaScore = AlphaScore; info.BetaScore = BetaScore; info.DeltaScore = DeltaScore;
end
