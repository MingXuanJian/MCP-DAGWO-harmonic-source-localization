function [Best_score,Best_pos,curve] = Standard_GWO(N,MaxIt,lb,ub,dim,fobj)
    N = max(5,round(N)); X = lb + rand(N,dim).*(ub-lb);
    fit = arrayfun(@(i) fobj(X(i,:)),1:N)'; curve = nan(MaxIt,1);
    for it = 1:MaxIt
        [fit,ord] = sort(fit,'ascend'); X = X(ord,:);
        Alpha = X(1,:); Beta = X(2,:); Delta = X(3,:);
        a = 2*(1-it/MaxIt);
        for i = 1:N
            Xcand = (gwo_leader_update(X(i,:),Alpha,a)+gwo_leader_update(X(i,:),Beta,a)+gwo_leader_update(X(i,:),Delta,a))/3;
            Xcand = BoundClampRow(Xcand,lb,ub);
            fc = fobj(Xcand);
            if fc < fit(i), X(i,:) = Xcand; fit(i) = fc; end
        end
        curve(it) = min(fit);
    end
    [Best_score,idx] = min(fit); Best_pos = X(idx,:);
end
