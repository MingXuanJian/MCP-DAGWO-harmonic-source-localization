function X = initialize_population_dagwo(N,dim,lb,ub,initSeeds)
    X = zeros(N,dim); cnt = 0;
    if ~isempty(initSeeds)
        ns = min(size(initSeeds,1),N);
        for i = 1:ns
            cnt = cnt + 1;
            X(cnt,:) = BoundClampRow(initSeeds(i,:),lb,ub);
        end
    end
    G = GoodPointMatrix(N,dim);
    while cnt < N
        cnt = cnt + 1;
        if rand < 0.5
            x = lb + G(cnt,:).*(ub-lb);
        else
            x = lb + rand(1,dim).*(ub-lb);
        end
        if rand < 0.25, x = lb + ub - x; end
        X(cnt,:) = BoundClampRow(x,lb,ub);
    end
end

%% ========================================================================
% Standard GWO and PSO baselines
% ========================================================================
