function Xnew = gwo_leader_update(Xi,Leader,a)
    dim = numel(Xi);
    r1 = rand(1,dim); r2 = rand(1,dim);
    A = 2*a*r1 - a; C = 2*r2;
    D = abs(C.*Leader - Xi);
    Xnew = Leader - A.*D;
end
