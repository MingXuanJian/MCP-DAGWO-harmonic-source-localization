function [Best_score,Best_pos,curve] = PSO_MCP(N,MaxIt,lb,ub,dim,fobj)
    N = max(5,round(N)); X = lb + rand(N,dim).*(ub-lb); V = zeros(N,dim);
    fit = arrayfun(@(i) fobj(X(i,:)),1:N)'; Pbest = X; Pfit = fit;
    [Best_score,idx] = min(fit); Best_pos = X(idx,:); curve = nan(MaxIt,1);
    for it = 1:MaxIt
        w = 0.9 - (0.9-0.4)*it/MaxIt; c1 = 1.5; c2 = 1.5;
        for i = 1:N
            V(i,:) = w*V(i,:) + c1*rand(1,dim).*(Pbest(i,:)-X(i,:)) + c2*rand(1,dim).*(Best_pos-X(i,:));
            X(i,:) = BoundClampRow(X(i,:)+V(i,:),lb,ub);
            f = fobj(X(i,:));
            if f < Pfit(i), Pfit(i) = f; Pbest(i,:) = X(i,:); end
            if f < Best_score, Best_score = f; Best_pos = X(i,:); end
        end
        curve(it) = Best_score;
    end
end

%% ========================================================================
% Objective and MCP repair
% ========================================================================
